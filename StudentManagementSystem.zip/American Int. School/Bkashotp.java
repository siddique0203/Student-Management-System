import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;




public  class Bkashotp extends JFrame  {
	private JLabel Amount;
    private JButton closebutton;
    private JPasswordField email;
    public static JLabel AmountNumber;
    private JCheckBox jCheckBox1;
    private JLabel jLabel1;
    private JLabel marchant;
    private JLabel marchantname;
    private JButton probutton;
    private JLabel word;
    private JLabel box;
    private Container c;
    private JLabel name;
    private JLabel tnx;

    
    public Bkashotp() {

    
        tnx=new JLabel();
        name=new JLabel();
        jCheckBox1 = new JCheckBox();
        probutton = new JButton();
        closebutton = new JButton();
        email = new JPasswordField();
        marchant = new JLabel();
        marchantname = new JLabel();
        Amount = new JLabel();
        AmountNumber = new JLabel();
        word = new JLabel();
        jLabel1 = new JLabel();
        box = new JLabel();
		
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(null);


        c=this.getContentPane();
        c.setBackground(Color.red);

        name.setBounds(250,100,200,30);
        name.setText("bkash");
        name.setFont(new Font("Arial", Font.BOLD, 38));
        add(name);

        probutton.setFont(new Font("Inter", Font.PLAIN, 14));
        probutton.setText("PROCEED");
        add(probutton);
        probutton.setBounds(150, 630, 130, 25);

        closebutton.setFont(new Font("Inter", Font.PLAIN, 14));
        closebutton.setText("CLOSE");
        add(closebutton);
        closebutton.setBounds(300, 630, 100, 25);

 
        add(email);
        email.setBounds(175, 520, 200, 30);

             marchant.setFont(new Font("Inter", Font.BOLD, 14)); 
        marchant.setForeground(new Color(255, 255, 255));
        marchant.setText("Merchant          :");
        add(marchant);
        marchant.setBounds(160, 210, 120, 30);

        //marchantname.setFont(new Font("Inter", Font.BOLD, 14));
        marchantname.setForeground(new Color(255, 255, 255));
        marchantname.setText("American International School");
        add(marchantname);
        marchantname.setBounds(290, 220, 190, 18);

      /*  Amount.setFont(new Font("Inter", Font.BOLD, 14));
        Amount.setForeground(new Color(255, 255, 255));
        Amount.setText("Amount             :");
         add(Amount);
        Amount.setBounds(160, 260, 120, 18);

        
	    AmountNumber.setFont(new Font("Inter", Font.BOLD, 14));
		 AmountNumber.setForeground(new Color(255, 255, 255));
        add(AmountNumber);
        AmountNumber.setBounds(300, 260, 100, 18);    */

        word.setFont(new Font("Inter", Font.BOLD, 14)); 
        word.setForeground(new Color(255, 255, 255));
        word.setText("Enter your OTP ");
        add(word);
        word.setBounds(210, 465, 210, 40);

        probutton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                new Tnx();
                setVisible(false);
            }});


        pack();
		setSize(615, 800);
		setResizable(false);
		setVisible(true);
        setLocationRelativeTo(null);


    }




    public static void main(String args[]) {

      new Bkashotp();
    }

               
}
public interface iNagad {
    public void Na();
}

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class LoginPage extends JFrame implements ActionListener {
    JFrame frame;
    private Container c;
    //JPanel c;
    JLabel userLabel, passwordLabel, errorLabel,intro,i2,up;
    JTextField userText;
    JPasswordField passwordText;
    JButton loginButton, signupButton, exitButton,usr,adm;
    Font f,font;


    ArrayList<String> users = new ArrayList<String>();
    ArrayList<String> passwords = new ArrayList<String>();

    public LoginPage() {
        f=new Font("Arial",Font.BOLD,16);
        font=new Font("Arial",Font.BOLD,28);
        c=this.getContentPane();
        c.setBackground(Color.green);

        frame = new JFrame("Login Page");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(true);
        frame.setBounds(100,100,800,500);

        //c = new JPanel();
        c.setLayout(null);


        intro=new JLabel("Student Management system");
        intro.setBounds(200,01,420,100);
        intro.setFont(font);
        c.add(intro);

        i2=new JLabel("Developed by  SIDDIQUE & IFTE");
        i2.setBounds(395,27,420,100);
        c.add(i2);

        userLabel = new JLabel("Username:");
        c.add(userLabel);
        userLabel.setBounds(150,105,100,25);
        userLabel.setFont(f);

        up=new JLabel("If you don't have any account, press SignUp to create account");
        up.setBounds(190,190,390,30);
        c.add(up);

        userText = new JTextField();
        c.add(userText);
        userText.setFont(f);
        userText.setBounds(240,107,300,27);

        passwordLabel = new JLabel("Password:");
        c.add(passwordLabel);
        passwordLabel.setBounds(150,145,100,25);
        passwordLabel.setFont(f);

        passwordText = new JPasswordField();
        c.add(passwordText);
        passwordText.setFont(f);
        passwordText.setBounds(240,147,300,27);

        //loginButton = new JButton("Login");
        //loginButton.addActionListener(this);
        //loginButton.setBounds(150,300,150,40);

        signupButton = new JButton("Sign Up");
        signupButton.addActionListener(this);
        c.add(signupButton);
        signupButton.setBounds(550,300,150,40);
        signupButton.setFont(f);

        exitButton = new JButton("Exit");
        exitButton.addActionListener(this);
        c.add(exitButton);
        exitButton.setBounds(270,380,150,40);
        exitButton.setFont(f);

        usr=new JButton("Student Login");
        usr.addActionListener(this);
        usr.setForeground(Color.white);
        usr.setBounds(115,300,150,40);
        usr.setBackground(Color.red);
        usr.setFont(f);
        c.add(usr);

        adm=new JButton("Admin Login");
        adm.addActionListener(this);
        adm.setForeground(Color.white);
        adm.setBounds(335,300,150,40);
        adm.setBackground(Color.red);
        adm.setFont(f);
        c.add(adm);


        errorLabel = new JLabel("");
        c.add(errorLabel);
        errorLabel.setBounds(250,250,400,40);
        errorLabel.setFont(f);

        frame.add(c);
        frame.setVisible(true);

        // Add default user
        users.add("siddique");
        passwords.add("1234");
    }



    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginButton) {
            String user = userText.getText();
            String password = new String(passwordText.getPassword());

            if (users.contains(user) && passwords.contains(password)) {
                errorLabel.setText("Login successful.");
            } else {
                errorLabel.setText("Invalid username or password.");
            }
        } else if (e.getSource() == usr) {
            String user = userText.getText();
            String password = new String(passwordText.getPassword());

            if (users.contains(user) && passwords.contains(password)) {
                //errorLabel.setText("Login successful.");
                StudentTable st = new StudentTable("student");
                st.setBounds(360, 30, 750, 750);
                st.setTitle("Student");
                st.setVisible(true);

            } else {
                errorLabel.setText("Invalid username or password.");
            }

        } else if (e.getSource() == adm) {
            String user = userText.getText();
            String password = new String(passwordText.getPassword());

            if (users.contains(user) && passwords.contains(password)) {
                // errorLabel.setText("Login successful.");
                StudentTable ad = new StudentTable("admin", "adm");
                ad.setBounds(360, 30, 750, 750);
                ad.setTitle("Admin");
                ad.setVisible(true);

            } else {
                errorLabel.setText("Invalid username or password.");
            }
        } else if (e.getSource() == signupButton) {
            String user = userText.getText();
            String password = new String(passwordText.getPassword());

            if (users.contains(user)) {
                errorLabel.setText("Username already taken.");
            } else {
                users.add(user);
                passwords.add(password);
                errorLabel.setText("Sign up successful.");
            }
        } else if (e.getSource() == exitButton) {
            System.exit(0);
        }
    }

    public static void main(String[] args) {
        new LoginPage();
    }
}

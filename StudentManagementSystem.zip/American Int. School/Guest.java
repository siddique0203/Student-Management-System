import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Guest extends  JFrame  {
    private JFrame frame;
    private ImageIcon img;
    private JLabel paymentAmountlLabel;
    private JPanel paymentAmountpanel;
    private JPanel PaymentMethodPanel;
    private JButton signUp;
    private JButton paymentButton;
    private JComboBox PaymentComboBox;
    private JComboBox fundComboBox;
    private Container c ;
    public static JTextField paymentAmountTextField;
    private JLabel paymentMethodLabel;
    private JLabel background;
    private JLabel imglabel;
     private String []method={"Bkash","Nagad"};


    public Guest() {

        c=this.getContentPane();
        c.setBackground(Color.GREEN);

        img=new ImageIcon(getClass().getResource("Screenshot (276).png"));
        imglabel=new JLabel(img);
        imglabel.setBounds(40,40,600,140);
        c.add(imglabel);


        paymentAmountpanel =new JPanel();
        PaymentMethodPanel =new JPanel();

        paymentAmountTextField = new JTextField();
        PaymentComboBox= new JComboBox(method);
        paymentButton = new JButton();


        setDefaultCloseOperation(EXIT_ON_CLOSE);

		setLayout(null);

        paymentAmountpanel.setBackground(new Color(234, 250, 241));
        paymentAmountpanel.setLayout(null);

        paymentAmountTextField.setBackground(new Color(234, 250, 241));
        paymentAmountTextField.setBorder(null);
		
	/*	donateAmountTextField.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				
				//Bkash c=new Bkash();
				String s=donateAmountTextField.getText();
				//c.my_update(s);
				//Bkashpin b=new Bkashpin();
				new Bkash(s).setVisible(true);
				//setVisible(false);
				}});
			*/



        paymentAmountpanel.add(paymentAmountTextField);
        paymentAmountTextField.setBounds(10, 40, 390, 30);

        paymentAmountlLabel=new JLabel();
        paymentAmountlLabel.setBackground(Color.pink);
        paymentAmountlLabel.setFont(new Font("Inter", 0, 14));
        paymentAmountlLabel.setText("Payment Amount");
        paymentAmountlLabel.setBackground(Color.red);
        paymentAmountpanel.add(paymentAmountlLabel);
        paymentAmountlLabel.setBounds(10, 10, 330, 20);

        add(paymentAmountpanel);
        paymentAmountpanel.setBounds(75, 313, 525, 80);

        PaymentMethodPanel=new JPanel();
        PaymentMethodPanel.setBackground(new Color(234, 250, 241));
        PaymentMethodPanel.setLayout(null);

        paymentMethodLabel=new JLabel();
        paymentMethodLabel.setFont(new Font("Inter", 0, 14));
        paymentMethodLabel.setText("Payment method");
        PaymentMethodPanel.add(paymentMethodLabel);
        paymentMethodLabel.setBounds(10, 10, 160, 18);

        PaymentComboBox=new JComboBox(method);
        PaymentComboBox.setBackground(new Color(234, 250, 241));
        PaymentComboBox.setBorder(null);
        PaymentMethodPanel.add(PaymentComboBox);
        PaymentComboBox.setBounds(20, 45, 72, 20);

        add(PaymentMethodPanel);
        PaymentMethodPanel.setBounds(75, 410, 525, 80);


        paymentButton.setFont(new Font("Inter", 1, 18));
        paymentButton.setForeground(new Color(46, 204, 113));
        paymentButton.setText("Payment");
        paymentButton.setBorder(null);

        add(paymentButton);
        paymentButton.setBackground(Color.red);
        paymentButton.setForeground(Color.white);
        paymentButton.setBounds(360, 603, 240, 59);

		paymentButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){

				String s =PaymentComboBox.getSelectedItem().toString();
				if(s=="Bkash")
				{
					PaymentOperation b=new PaymentOperation();
                    b.bk();
					Bkashpin p=new Bkashpin();
					b.AmountNumber.setText(Guest.paymentAmountTextField.getText());
					p.setVisible(true);
					b.setVisible(true);
				}
				else if (s=="Nagad")
				{
					PaymentOperation n=new PaymentOperation();
                    n.Na();
					n.AmountNumber.setText(Guest.paymentAmountTextField.getText());
					n.setVisible(true);
				}

            }});



		this.setBounds(400,50,700, 750);
		this.setResizable(false);
		this.setVisible(true);
    }






    public static void main(String args[]) {


                new Guest();

        }
    }

                       

                   


import java.awt.*;
import  java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import javax.swing.*;
import javax.swing.ImageIcon;



public class Nagapin extends JFrame {
        private JLabel Amount;
    private JButton closebutton;
    private JPasswordField pin;
    public static JLabel AmountNumber;
    private JCheckBox jCheckBox1;
    private JLabel jLabel1;
    private JLabel marchant;
    private JLabel marchantname;
    private JButton probutton;
    private JLabel word;
    private JLabel error;
    private JLabel box;
    private Container c;
    private JLabel name;


    
    public Nagapin() {

    

        name=new JLabel();
        jCheckBox1 = new JCheckBox();
        probutton = new JButton();
        closebutton = new JButton();
        pin = new JPasswordField();
        marchant = new JLabel();
        marchantname = new JLabel();
        Amount = new JLabel();
        AmountNumber = new JLabel();
        word = new JLabel();
        jLabel1 = new JLabel();
        box = new JLabel();
        error=new JLabel();
		
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        c=this.getContentPane();
        c.setBackground(Color.orange);

        name.setBounds(250,100,200,90);
        name.setText("Nagad");
        name.setFont(new Font("Arial", Font.BOLD, 38));
        add(name);

        error.setBounds(230,550,100,30);
        add(error);

        probutton.setFont(new Font("Inter", Font.PLAIN, 14));
        probutton.setText("PROCEED");
        add(probutton);
        probutton.setBounds(150, 630, 130,25);
		probutton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){

                String password = new String(pin.getPassword());
                String fileData = "";
                boolean validCredentials = false;

                try {
                    File file = new File("F:\\code\\StudentManagement\\src\\Registration.txt");
                    Scanner scanner = new Scanner(file);

                    while (scanner.hasNextLine()) {
                        fileData += scanner.nextLine() + "\n";
                    }

                    scanner.close();

                    // Check if username and password match any registration data
                    if (fileData.contains("Pin: " + password)) {
                        validCredentials = true;
                    }

                } catch (FileNotFoundException ex) {
                    System.out.println("File not found: " + ex.getMessage());
                }

                if (validCredentials) {
                    Nagadotp b=new Nagadotp();
                    b.AmountNumber.setText(Nagapin.AmountNumber.getText());
                    b.setVisible(true);
                    setVisible(false);

                }
                else{
                    error.setText("Invalid Pin");
                }
            }});

        closebutton.setFont(new Font("Inter", Font.PLAIN, 14));
        closebutton.setText("CLOSE");
        add(closebutton);
        closebutton.setBounds(330, 630, 100, 25);
		closebutton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				System.exit(0);
				}});

 
        add(pin);
        pin.setBounds(175, 520, 200, 30);

           marchant.setFont(new Font("Inter", Font.BOLD, 14)); 
        marchant.setForeground(new Color(255, 255, 255));
        marchant.setText("Merchant          :");
        add(marchant);
        marchant.setBounds(160, 320, 120, 30);

        //marchantname.setFont(new Font("Inter", Font.BOLD, 14));
        marchantname.setForeground(new Color(255, 255, 255));
        marchantname.setText("American International School");
        add(marchantname);
        marchantname.setBounds(290, 325, 190, 18);

        Amount.setFont(new Font("Inter", Font.BOLD, 14)); 
        Amount.setForeground(new Color(255, 255, 255));
        Amount.setText("Amount             :");
         add(Amount);
        Amount.setBounds(160, 380, 120, 18);

   
		   AmountNumber.setFont(new Font("Inter", Font.BOLD, 14));
		 AmountNumber.setForeground(new Color(255, 255, 255));
        add(AmountNumber);
        AmountNumber.setBounds(300, 380, 100, 18);

        word.setFont(new Font("Inter", Font.BOLD, 14)); 
        word.setForeground(new Color(255, 255, 255));
        word.setText("Enter your PIN ");
        add(word);
        word.setBounds(210, 465, 210, 40);



        pack();
		setSize(615, 800);
		setResizable(false);
		setVisible(true);
        setLocationRelativeTo(null);
    }                      

   

    public static void main(String args[]) {
       
      new Nagapin();
    }

               
}

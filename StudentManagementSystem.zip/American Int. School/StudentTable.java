import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class StudentTable extends JFrame implements ActionListener{
    private JTable table;
    private DefaultTableModel model;
    private JScrollPane scroll;
    private Container c;
    private JFrame frame;
    private JLabel l1,l2,l3,l4,l5,p1;
    private JTextField t1,t2,t3,t4;
    private JButton add,upd,dlt,clr,pay;
    private Font font;
    private Font f1;



    private String [] colums={"NAME","ID","PHONE","GPA"};
    private String[] rows= new String[4];

    StudentTable (String student){
        c=this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.pink);

        font=new Font("Arial",Font.BOLD,16);
        f1=new Font("Arial",Font.BOLD,13);

        l1=new JLabel("Student Regestration");
        l1.setBounds(290,20,250,30);
        l1.setForeground(Color.blue);
        l1.setFont(font);
        c.add(l1);


        l2=new JLabel("Student Name");
        l2.setBounds(30,80,150,30);
        l2.setForeground(Color.darkGray);
        l2.setFont(f1);
        c.add(l2);

        l3=new JLabel("Student Id");
        l3.setBounds(30,120,150,30);
        l3.setForeground(Color.darkGray);
        l3.setFont(f1);
        c.add(l3);

        l4=new JLabel("Phone");
        l4.setBounds(30,160,150,30);
        l4.setForeground(Color.darkGray);
        l4.setFont(f1);
        c.add(l4);

        l5=new JLabel("GPA");
        l5.setBounds(30,200,150,30);
        l5.setForeground(Color.darkGray);
        l5.setFont(f1);
        c.add(l5);

        t1=new JTextField();
        t1.setBounds(130,80,270,30);
        t1.setFont(f1);
        c.add(t1);

        t2=new JTextField();
        t2.setBounds(130,120,270,30);
        t2.setFont(f1);
        c.add(t2);

        t3=new JTextField();
        t3.setBounds(130,160,270,30);
        t3.setFont(f1);
        c.add(t3);

        t4=new JTextField();
        t4.setBounds(130,200,270,30);
        t4.setFont(f1);
        c.add(t4);

        add=new JButton("ADD");
        add.setBounds(500,80,120,30);
        add.setFont(font);
        add.setBackground(Color.green);
        c.add(add);

       /* upd=new JButton("UPDATE");
        upd.setBackground(Color.green);
        upd.setFont(font);
        upd.setBounds(500,120,120,30);
        c.add(upd);

        dlt=new JButton("DELETE");
        dlt.setBounds(500,160,120,30);
        dlt.setFont(font);
        dlt.setBackground(Color.red);
        dlt.setForeground(Color.white);
        c.add(dlt);*/

        clr=new JButton("CLEAR");
        clr.setBounds(500,200,120,30);
        clr.setFont(font);
        clr.setBackground(Color.red);
        clr.setForeground(Color.white);
        c.add(clr);

        pay=new JButton("Pay Now");
        pay.setBounds(600,290,120,30);
        pay.setFont(font);
        pay.setForeground(Color.white);
        pay.setBackground(Color.darkGray);
        add(pay);

        p1=new JLabel("If you want to pay your tution fee via your phone number mobile banking, press \"Pay Now\" ");
        p1.setBounds(40,290,620,30);
        p1.setFont(f1);
        c.add(p1);

        table=new JTable();
        model=new DefaultTableModel();
        model.setColumnIdentifiers(colums);
        table.setModel(model);
        table.setFont(font);
        table.setSelectionBackground(Color.yellow);
        table.setBackground(Color.white);
        table.setRowHeight(30);

        scroll=new JScrollPane(table);
        scroll.setBounds(20,360,685,270);
        c.add(scroll);

        add.addActionListener(this);
        clr.addActionListener(this);
       // dlt.addActionListener(this);
        //upd.addActionListener(this);

        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int numberOfRow=table.getSelectedRow();
                String name=model.getValueAt(numberOfRow,0).toString();
                String id=model.getValueAt(numberOfRow,1).toString();
                String phone=model.getValueAt(numberOfRow,2).toString();
                String gpa=model.getValueAt(numberOfRow,3).toString();

                t1.setText(name);
                t2.setText(id);
                t3.setText(phone);
                t4.setText(gpa);
            }
        });




    }
    StudentTable() {
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.pink);

        font = new Font("Arial", Font.BOLD, 16);
        f1 = new Font("Arial", Font.BOLD, 13);
    }
    StudentTable(String admin,String n){
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.pink);

        font = new Font("Arial", Font.BOLD, 16);
        f1 = new Font("Arial", Font.BOLD, 13);

        l1=new JLabel("Student Regestration");
        l1.setBounds(290,20,250,30);
        l1.setForeground(Color.blue);
        l1.setFont(font);
        c.add(l1);

        l2=new JLabel("Student Name");
        l2.setBounds(30,80,150,30);
        l2.setForeground(Color.darkGray);
        l2.setFont(f1);
        c.add(l2);

        l3=new JLabel("Student Id");
        l3.setBounds(30,120,150,30);
        l3.setForeground(Color.darkGray);
        l3.setFont(f1);
        c.add(l3);

        l4=new JLabel("Phone");
        l4.setBounds(30,160,150,30);
        l4.setForeground(Color.darkGray);
        l4.setFont(f1);
        c.add(l4);

        l5=new JLabel("GPA");
        l5.setBounds(30,200,150,30);
        l5.setForeground(Color.darkGray);
        l5.setFont(f1);
        c.add(l5);

        t1=new JTextField();
        t1.setBounds(130,80,270,30);
        t1.setFont(f1);
        c.add(t1);

        t2=new JTextField();
        t2.setBounds(130,120,270,30);
        t2.setFont(f1);
        c.add(t2);

        t3=new JTextField();
        t3.setBounds(130,160,270,30);
        t3.setFont(f1);
        c.add(t3);

        t4=new JTextField();
        t4.setBounds(130,200,270,30);
        t4.setFont(f1);
        c.add(t4);

        add=new JButton("ADD");
        add.setBounds(500,80,120,30);
        add.setFont(font);
        add.setBackground(Color.green);
        c.add(add);

        upd=new JButton("UPDATE");
        upd.setBackground(Color.green);
        upd.setFont(font);
        upd.setBounds(500,120,120,30);
        c.add(upd);

        dlt=new JButton("DELETE");
        dlt.setBounds(500,160,120,30);
        dlt.setFont(font);
        dlt.setBackground(Color.red);
        dlt.setForeground(Color.white);
        c.add(dlt);

        clr=new JButton("CLEAR");
        clr.setBounds(500,200,120,30);
        clr.setFont(font);
        clr.setBackground(Color.red);
        clr.setForeground(Color.white);
        c.add(clr);

        pay=new JButton("Pay Now");
        pay.setBounds(600,290,120,30);
        pay.setFont(font);
        pay.setForeground(Color.white);
        pay.setBackground(Color.darkGray);
        add(pay);

        p1=new JLabel("If you want to pay your tution fee via your phone number mobile banking, press \"Pay Now\" ");
        p1.setBounds(40,290,620,30);
        p1.setFont(f1);
        c.add(p1);

        table=new JTable();
        model=new DefaultTableModel();
        model.setColumnIdentifiers(colums);
        table.setModel(model);
        table.setFont(font);
        table.setSelectionBackground(Color.yellow);
        table.setBackground(Color.white);
        table.setRowHeight(30);

        scroll=new JScrollPane(table);
        scroll.setBounds(20,360,685,270);
        c.add(scroll);

        add.addActionListener(this);
        clr.addActionListener(this);
        dlt.addActionListener(this);
        upd.addActionListener(this);
        pay.addActionListener(this);

        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
               int numberOfRow=table.getSelectedRow();
               String name=model.getValueAt(numberOfRow,0).toString();
               String id=model.getValueAt(numberOfRow,1).toString();
               String phone=model.getValueAt(numberOfRow,2).toString();
               String gpa=model.getValueAt(numberOfRow,3).toString();

               t1.setText(name);
               t2.setText(id);
               t3.setText(phone);
               t4.setText(gpa);
            }
        });

    }
    public void actionPerformed(ActionEvent e){
            if(e.getSource()==clr){
                t1.setText("");
                t2.setText("");
                t3.setText("");
                t4.setText("");


            }
            else if(e.getSource()==add){
                rows[0]=t1.getText();
                rows[1]=t2.getText();
                rows[2]=t3.getText();
                rows[3]=t4.getText();
                model.addRow(rows);

            }
            else if(e.getSource()==dlt){
                int numberOfRow =table.getSelectedRow();

                if(numberOfRow>=0){
                    model.removeRow(numberOfRow);
                }
                else{
                    JOptionPane.showMessageDialog(null,"Please select a row");
                }
            }
            else if(e.getSource()==upd){
                int numberOfRow=table.getSelectedRow();

              if(numberOfRow>=0) {
                  String name = t1.getText();
                  String id = t2.getText();
                  String phone = t3.getText();
                  String gpa = t4.getText();

                  model.setValueAt(name, numberOfRow, 0);
                  model.setValueAt(id, numberOfRow, 1);
                  model.setValueAt(phone, numberOfRow, 2);
                  model.setValueAt(gpa, numberOfRow, 3);
              }
              else{
                  JOptionPane.showMessageDialog(null,"Please Select a row");
              }


            }
            else if(e.getSource()==pay){
                Guest g=new Guest();
            }

    }

    public static void main(String []args){
        StudentTable frame=new StudentTable();
        frame.setBounds(360,30,750,750);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setTitle("Student Management System");
        frame.setResizable(false);
        frame.setVisible(true);
    }
}


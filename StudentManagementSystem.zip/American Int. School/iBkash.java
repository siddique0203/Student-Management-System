public interface iBkash {
    public void bk();
}

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Tnx extends JFrame {
    private JLabel tn;
    private JButton exit,home;
    public Tnx(){

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);

        home=new JButton("Home");
        home.setFont(new Font("Arial",Font.BOLD,20));
        home.setBounds(100,600,100,50);
        home.setBackground(Color.green);
        add(home);

        exit=new JButton("Exit");
        exit.setFont(new Font("Arial",Font.BOLD,20));
        exit.setBounds(400,600,100,50);
        exit.setBackground(Color.red);
        add(exit);


        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        home.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                LoginPage f=new LoginPage();
                f.setVisible(true);
                setVisible(false);
            }
        });


        tn=new JLabel("Payment Successful");
        tn.setBounds(90,300,600,100);
        tn.setFont(new Font("Arial",Font.BOLD,40));
        add(tn);

        setSize(615, 800);
        setResizable(false);
        setVisible(true);
        setLocationRelativeTo(null);
    }

    public static void main(String args[]){

        Tnx t=new Tnx();



    }
}
